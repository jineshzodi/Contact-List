-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Apr 18, 2016 at 10:35 PM
-- Server version: 5.5.48-cll
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `z0d1aac8_contact`
--

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE IF NOT EXISTS `contacts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `campaign_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `surname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `efield1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `efield2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `efield3` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `efield4` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `efield5` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=26 ;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `user_id`, `campaign_id`, `name`, `surname`, `email`, `phone`, `efield1`, `efield2`, `efield3`, `efield4`, `efield5`, `created_at`, `updated_at`) VALUES
(7, 6, 0, 'shihabudeen', 'mm', 'mm.shihab.shihab@gmail.com', '09497405079', '', '', '', '', '', '2016-04-16 06:25:48', '2016-04-16 06:25:48'),
(13, 7, 10, 'SC', 'zxvx', 'scf@sd.com', '13435667', '', '', '', '', '', '2016-04-17 03:42:18', '2016-04-17 03:42:18'),
(14, 7, 11, 'gfh', 'fdgfh', 'hg@ghj.co', '354678887', '', '', '', '', '', '2016-04-17 03:44:40', '2016-04-17 03:44:40'),
(20, 11, 5, 'test', 'test', 'sf@d.vom', '23436768', 'sdgdf', 'gvfhgj', '', '', '', '2016-04-18 00:12:54', '2016-04-18 00:21:13');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2016_04_13_055142_create_tasks_table', 1),
('2016_04_13_072937_create_cars_table', 1),
('2016_04_13_085858_create_contacts_table', 1),
('2016_04_15_091256_create_social_accounts_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `social_accounts`
--

CREATE TABLE IF NOT EXISTS `social_accounts` (
  `user_id` int(11) NOT NULL,
  `provider_user_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `provider` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `social_accounts`
--

INSERT INTO `social_accounts` (`user_id`, `provider_user_id`, `provider`, `created_at`, `updated_at`) VALUES
(10, '1279362462091534', 'facebook', '2016-04-18 00:01:36', '2016-04-18 00:01:36'),
(11, '10201613804182801', 'facebook', '2016-04-18 00:12:28', '2016-04-18 00:12:28'),
(10, '8371859', 'github', '2016-04-18 00:13:18', '2016-04-18 00:13:18'),
(12, '10156830213950224', 'facebook', '2016-04-18 00:13:47', '2016-04-18 00:13:47');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(3, 'Athul', 'athul@sathraservices.com', '$2y$10$rHDTzAXVFevJc80VB0kRH.UVH2gsDAggvUy/ohDO4dBw7XoZLOWPi', 'twvKFqtDw1Eo7eExxvI2151RNzgtCKpQdd6XKjhiR60ajMaiEfRSMeZkQeU0', '2016-04-15 05:57:08', '2016-04-15 06:03:09'),
(5, 'shihab', 'shihab@sathraservices.com', '$2y$10$WJjjKlKoKgWWwePWp6JJB.e.jsrKCpfrSgRsj/2.LElrtHrwAGqU2', 'rBgjZV0HhYGGWX1OAoPqgY1cKIqVP62yuocymWXgmuvPrx3af0XyqlJoKEEc', '2016-04-15 21:52:49', '2016-04-18 02:29:02'),
(6, 'Test', 'test@zodiacteam.com', '$2y$10$gyx6O5lAnSNvVdFeAidzN.DAyBovUclK56imZ9dD03c5t3fgkoZCm', 'whfsueN0yf0OdJfKZTDPQv3Vumg2GbRlqvyvFdIL5b1tyFdoKG1eKekkmsSC', '2016-04-16 06:06:01', '2016-04-16 06:27:44'),
(7, 'jinesh', 'sathraservices@gmail.com', '$2y$10$UuRxAtNaoV2csNzI9dX4jeflffZ5THurofE.Us0M0h88.ka30nCbC', 'Jf5y30lLwS4lLxESBKrps3FgBoD54rkUnQ6RtOwVrKlBpwNBw9LwLgoeFwIZ', '2016-04-16 07:22:53', '2016-04-18 01:48:36'),
(8, 'Deleep Bose', 'deleep@sathraservices.com', '$2y$10$t2H9K40ht7kmWUfnow8lGehbVk3p0dalS29m1YaxE1AAtP5qR9w62', 'TonqFhDXy8IXnZ4JzDb5wlURfqQ0zqk5ttnJAuzhNyA5yigv7qqXMxctYPmd', '2016-04-17 23:52:12', '2016-04-18 00:23:14'),
(10, 'Shihab Mv Muttil', 'mm.shihab.shihab@gmail.com', '', 'Ah5R6QikIMpcXRZC0EWNYDOyU6e1XqzN6G0V96137ABeXuU66gnRIaaGduGy', '2016-04-18 00:01:36', '2016-04-18 00:13:23'),
(11, 'Jinesh Bose Karimattathil', 'jineshbose@gmail.com', '', 'GUBQ9jw1Ax6IxsDy8YgjrmMhEagjAIReAdZT67CaukjjxcAnfeiWBtzMTK41', '2016-04-18 00:12:28', '2016-04-18 01:47:40'),
(12, 'Deleep Bose', 'dilipdavinci@gmail.com', '', 'Nqo7QW5y5xV63MR7F4G1xNtjQa1TtStVWbrXJWJsty1olb2KjCiYcKrzTdzN', '2016-04-18 00:13:47', '2016-04-18 00:18:30'),
(13, 'asd', 'vf@gmail.com', '$2y$10$zS1QvG/ez4xvZYWqxKth5.Wlr5xbwxGFaPv.2e1fGVJ3k/1Z2u6bu', 'rEXEmtXdrNbawWYS5QF8xoR5PP6R5K4RC4s3zq3Th2cnKRlDJ97cj6c0uvgj', '2016-04-18 01:49:38', '2016-04-18 01:49:51');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
