<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Contact;
use Illuminate\Support\Facades;

class ContactController extends Controller {

    //Active Campaign URl and Secret 
    public $url = "https://zodiac594.api-us1.com";
    public $secret = "adea0fb181d77bbffc30ea9867cbab89decf67b565d350a3418f79daf6e7ec41c4baf55a";
    public $q = '';

    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource with Pagination and Search
     *
     * @return Response
     */
    public function index(Request $request) {
        $this->q = $request->get('q');
        $contacts = Contact::orderBy('created_at', 'asc')->where('user_id', '=', Facades\Auth::id())
                ->where(function($query) {
                    $query->where('name', 'like', '%' . $this->q . '%')
                    ->orWhere('surname', 'like', '%' . $this->q . '%')
                    ->orWhere('email', 'like', '%' . $this->q . '%')
                    ->orWhere('phone', 'like', '%' . $this->q . '%');
                })
                ->paginate(10);

        return view('contact.index', ['contacts' => $contacts, 'q' => $this->q]);
    }

    public function show($id) {
        $contacts = Contact::orderBy('created_at', 'asc')->where('user_id', '=', Facades\Auth::id())->paginate(10);
        return view('contact.show', ['contacts' => $contacts, 'q' => $this->q]);
    }

    /**
     * Store a newly created Contact in database with validation
     * and strore the data to active campaign also.
     *
     * @return Response
     */
    public function store(Request $request) {
        $validator = \Validator::make($request->all(), [
                    'name' => 'required',
                    'surname' => 'required',
                    'email' => 'required',
                    'phone' => 'required|min:8|max:16',
        ]);

        if ($validator->fails()) {
            return "invalid_form";
        }

        $campaignObj = new \ActiveCampaign($this->url, $this->secret);
        $post_data = [
            'p[123]' => "1",
            'first_name' => $request->name,
            'last_name' => $request->surname,
            'email' => $request->email,
            'phone' => $request->phone];
        $response = $campaignObj->api("contact/add", $post_data);

        $contact = new Contact;
        $contact->user_id = Facades\Auth::id();
        if ($response->success)
            $contact->campaign_id = $response->subscriber_id;

        $contact->name = $request->name;
        $contact->surname = $request->surname;
        $contact->email = $request->email;
        $contact->phone = $request->phone;
        $contact->efield1 = $request->field1;
        $contact->efield2 = $request->field2;
        $contact->efield3 = $request->field3;
        $contact->efield4 = $request->field4;
        $contact->efield5 = $request->field5;
        $contact->save();

        $contacts = Contact::orderBy('created_at', 'asc')->where('user_id', '=', Facades\Auth::id())->paginate(10);
        return view('contact.store', array('contacts' => $contacts));
    }

    /**
     * Load popup Form when adding a new contact.
     */
    public function loadform() {
        return view('contact.loadform');
    }

    /**
     * Show the form for editing the specified resource.
     * The specific data row to edit returns with the view 
     * 
     */
    public function edit($id) {
        $contact = new Contact;
        $row = $contact->find($id);
        return view('contact.edit', ['contact' => $row]);
    }

    /**
     * Update the specific edited row in database.
     * Also the updation will take effect in Active Campaign
     */
    public function update($id, Request $request) {
        $validator = \Validator::make($request->all(), [
                    'name' => 'required',
                    'surname' => 'required',
                    'email' => 'required',
                    'phone' => 'required|min:8|max:16',
        ]);

        if ($validator->fails()) {
            return "invalid_form";
        }
        $contact = Contact::find($id);
        $campaign_id = $contact->campaign_id;
        $campaignObj = new \ActiveCampaign($this->url, $this->secret);
        $post_data = array(
            'p[123]' => 1,
            'id' => $campaign_id,
            'first_name' => $request->name,
            'last_name' => $request->surname,
            'email' => $request->email,
            'phone' => $request->phone);
        $response = $campaignObj->api("contact/edit", $post_data);

        $contact->name = $request->name;
        $contact->surname = $request->surname;
        $contact->email = $request->email;
        $contact->phone = $request->phone;
        $contact->efield1 = $request->field1;
        $contact->efield2 = $request->field2;
        $contact->efield3 = $request->field3;
        $contact->efield4 = $request->field4;
        $contact->efield5 = $request->field5;

        $contact->save();
        $contacts = Contact::orderBy('created_at', 'asc')->where('user_id', '=', Facades\Auth::id())->paginate(10);
        return view('contact.store', array('contacts' => $contacts));
    }

    /**
     * Remove the specified contact from storage.
     *
     * 
     */
    public function destroy($id, Request $request) {
        $contact = Contact::find($id);
        $campaign_id = $contact->campaign_id;
        $contact->delete();
        $campaignObj = new \ActiveCampaign($this->url, $this->secret);
        $response = $campaignObj->api("contact/delete", array('id' => $campaign_id));
        $contacts = Contact::orderBy('created_at', 'asc')->where('user_id', '=', Facades\Auth::id())->paginate(10);
        return view('contact.store', array('contacts' => $contacts));
    }

}
