<?php $__env->startSection('content'); ?>
<section class="head-cell">
    <div class="container head-main">
        <div class="col-md-2"></div>
        <div class="col-md-8 white-cell">
            <div class="col-md-8">
                <?php echo Form::open(['method'=>'GET','id'=>'frm-search']); ?>

                    <div class="input-group">
                        <?php echo e(Form::text('q','',['class'=>'form-control','placeholder'=>'Search','id'=>'txtsearch'])); ?>

                        <div class="input-group-btn">
                            <button class="btn btn-default btn-44" type="submit"><i class="glyphicon glyphicon-search"></i></button>
                        </div>
                    </div>
                <?php echo Form::close(); ?>

            </div>
            <div class="col-md-4">
                <button type="button" class="btn btn-default navbar-btn btn-13" onclick="loadAdd()"  data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-plus"></span> ADD TO CONTACT</button>

            </div>
        </div>
        <div class="col-md-2"></div>
    </div>
</section>
<div class="container">
    <div class="head-b hidden-xs">
        <div class="col-md-2">Name </div>
        <div class="col-md-2">Surname</div>
        <div class="col-md-4">Email</div>
        <div class="col-md-2">Phone</div>
        <div class="col-md-2"> </div>
    </div>

    <div class="clearfix"></div>
    <div id="contacts-list">
        <?php if(count($contacts) > 0): ?>
        <?php foreach($contacts as $contact): ?>
        <div class="dash-board">

            <div class="col-md-2 hd-1"><?php echo e($contact->name); ?></div>
            <div class="col-md-2 hd-2"><?php echo e($contact->surname); ?></div>
            <div class="col-md-4 hd-3"><?php echo e($contact->email); ?></div>
            <div class="col-md-2 hd-4"><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span><?php echo e($contact->phone); ?></div>
            <div class="col-md-2">
                <button type="button" class="btn btn-23" onclick="deleteCon(<?php echo e($contact->id); ?>)"> <span class="glyphicon glyphicon-minus"></span> </button>
                <button type="button" class="btn btn-23" data-toggle="collapse" data-target="#collapse<?php echo e($contact->id); ?>" aria-expanded="false" aria-controls="collapseExample"> <span class="glyphicon glyphicon-plus"></span> </button>
                <button type="button" class="btn btn-23" onclick="loadEdit(<?php echo e($contact->id); ?>)" data-toggle="modal" data-target="#myModal"> <span class="glyphicon glyphicon-pencil"></span> </button>
            </div>
            <div class="clearfix"></div>

            <div class="collapse" id="collapse<?php echo e($contact->id); ?>">
                <div class="well">
                    <?php if($contact->efield1 == '' && $contact->efield2 == '' && $contact->efield3 == '' && $contact->efield4 =='' && $contact->efield5 ==''): ?>
                      There are no extra data available 
                    <?php else: ?>
                    <?php echo e($contact->efield1); ?>  <?php echo e(' - '.$contact->efield2); ?>  <?php echo e(' - '.$contact->efield3); ?>  <?php echo e(' - '.$contact->efield4); ?>  <?php echo e($contact->efield5); ?>

                   <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        <?php elseif(isset($q)): ?>
            <p style="text-align: center;padding: 20px;">There are no items that match your search.</p>
        <?php else: ?>
            <p style="text-align: center;padding: 20px;">There are no contacts added.</p>
        <?php endif; ?>            
        
        
        <!--Pagination-->
        <div class="col-md-8 col-md-offset-4">
            <?php echo $contacts->appends(['q' => $q])->links(); ?>

        </div>
        <!--Pagination-->
 
    </div>
    <!-- list-col ends -->
</div>
<!-- Modal / Quote pop upe starts 
        ----------------------------------------->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Add <span>/</span> Edit <span>/</span> Delete <span>/</span> <strong>Contact</strong></h4>
            </div>
            <?php echo Form::open(['','class'=>'form-horizontal','id'=>'frm-contact','role'=>'form']); ?>

            <?php echo csrf_field(); ?>

            <div class="modal-body">
                <article>
                    <div class="alert alert-info" style="display: none"></div>
                    <div class="form-group">
                        <div class="col-sm-12">
                            <?php echo Form::text('name','', ['class'=>'form-control','placeholder'=>'Name']);; ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-12">
                            <?php echo Form::text('surname','', ['class'=>'form-control','placeholder'=>'Surname']);; ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-12">
                            <?php echo Form::email('email','', ['class'=>'form-control','placeholder'=>'Email']);; ?>

                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-12">
                            <?php echo Form::number('phone','', ['class'=>'form-control','placeholder'=>'Phone']);; ?>

                        </div>
                    </div>
                    <div id="extrafields">
                        <div class="form-group efiled1" style="display: none">
                            <div class="col-sm-11 col-xs-11">
                                <?php echo Form::text('field1','', ['class'=>'form-control','placeholder'=>'']);; ?>

                            </div>
                            <div class="col-sm-1 col-xs-1">
                                <button type="button" onclick="removefi('efiled1')" class="btn btn-23 pull-right"> <span class="glyphicon glyphicon-minus"></span> </button>
                            </div>
                        </div>
                        <div class="form-group efiled2" style="display: none">
                            <div class="col-sm-11 col-xs-11">
                                <?php echo Form::text('field2','', ['class'=>'form-control','placeholder'=>'']);; ?>

                            </div>
                            <div class="col-sm-1 col-xs-1">
                                <button type="button" onclick="removefi('efiled2')" class="btn btn-23 pull-right"> <span class="glyphicon glyphicon-minus"></span> </button>
                            </div>
                        </div>
                        <div class="form-group efiled3" style="display: none">
                            <div class="col-sm-11 col-xs-11">
                                <?php echo Form::text('field3','', ['class'=>'form-control','placeholder'=>'']);; ?>

                            </div>
                            <div class="col-sm-1 col-xs-1">
                                <button type="button" onclick="removefi('efiled3')" class="btn btn-23 pull-right"> <span class="glyphicon glyphicon-minus"></span> </button>
                            </div>
                        </div>
                        <div class="form-group efiled4" style="display: none">
                            <div class="col-sm-11 col-xs-11">
                                <?php echo Form::text('field4','', ['class'=>'form-control','placeholder'=>'']);; ?>

                            </div>
                            <div class="col-sm-1 col-xs-1">
                                <button type="button" onclick="removefi('efiled4')" class="btn btn-23 pull-right"> <span class="glyphicon glyphicon-minus"></span> </button>
                            </div>
                        </div>
                        <div class="form-group efiled5" style="display: none">
                            <div class="col-sm-11 col-xs-11">
                                <?php echo Form::text('field5','', ['class'=>'form-control','placeholder'=>'']);; ?>

                            </div>
                            <div class="col-sm-1 col-xs-1">
                                <button type="button" onclick="removefi('efiled5')" class="btn btn-23 pull-right"> <span class="glyphicon glyphicon-minus"></span> </button>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <button type="button" id="btn-addfield" class="btn btn-23 pull-right" style="color: #000 !important"> <span class="glyphicon glyphicon-plus"></span> Add Field</button>
                        </div>
                    </div>
                </article>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn  btn-primary btn-default-3" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-default">Save &amp; Submit</button>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<!-- Modal / Quote pop upe ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>