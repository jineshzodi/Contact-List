<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-4">

        </div>
        <div class="col-md-4 text-center" style="margin: 100px auto">
            <h1 style="font-size: 10em">404</h1>
            <h2>Page Not Found</h2>  
        </div>
        <div class="col-md-4">

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>