<?php $__env->startSection('content'); ?>
<div class="panel-body">
    <!-- Display Validation Errors -->
    <?php echo $__env->make('common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="col-md-3"></div>
    <!-- New Task Form -->
    <div class="col-md-6">
        <?php echo Form::open(['route'=>'contacts.store']); ?>

        <?php echo csrf_field(); ?>

        <div class="form-group">
            <?php echo Form::text('name','', ['class'=>'form-control','placeholder'=>'Name']);; ?>

        </div>
        <div class="form-group">
            <?php echo Form::text('surname','', ['class'=>'form-control','placeholder'=>'Surname']);; ?>

        </div>
        <div class="form-group">
            <?php echo Form::email('email','', ['class'=>'form-control','placeholder'=>'Email']);; ?>

        </div>
        <div class="form-group">
            <?php echo Form::text('phone','', ['class'=>'form-control','placeholder'=>'Phone']);; ?>

        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-default">
                <i class="fa fa-plus"></i> Add Contact
            </button>
        </div>
        <?php echo Form::close(); ?>

    </div>
    <div class="col-md-3"></div>
</div>

<!-- Current Tasks -->
<?php if(!empty($contacts)): ?>
<div class="panel panel-default">
    <div class="panel-heading">
        Contact List
    </div>

    <div class="panel-body">
        <table class="table table-striped task-table">

            <!-- Table Headings -->
            <thead>
            <th>Name</th>
            <th>Surname</th>
            <th>Email</th>
            <th>Phone</th>
            <th style="width: 3.5em">&nbsp;</th>
            <th style="width: 3.5em">&nbsp;</th>
            </thead>

            <!-- Table Body -->
            <tbody>
                <?php foreach($contacts as $contact): ?>
                <tr>
                    <!-- Task Name -->
                    <td class="table-text">
                        <div><?php echo e($contact->name); ?></div>
                    </td>
                    <td>
                        <div><?php echo e($contact->surname); ?></div>
                    </td>
                    <td>
                        <div><?php echo e($contact->email); ?></div>
                    </td>
                    <td>
                        <div><?php echo e($contact->phone); ?></div>
                    </td>

                    <td>
                        <a href="<?php echo e(route('contacts.edit', $contact->id)); ?>" class="btn btn-primary">
                            <i class="fa fa-pencil"></i>Edit
                        </a>
                    </td>
                    <td>
                        <form action="<?php echo e(url('contacts/'.$contact->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <?php echo method_field('DELETE'); ?>


                            <button type="submit" class="btn btn-danger">
                                <i class="fa fa-trash"></i> Delete
                            </button>
                        </form>
                    </td>

                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>