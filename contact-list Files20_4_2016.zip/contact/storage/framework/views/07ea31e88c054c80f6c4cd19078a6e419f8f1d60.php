﻿<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
        <link rel="icon" href="images/favicon.ico" type="image/x-icon">
        <title>Contact Book</title>

        <!-- Bootstrap core CSS -->
        <link href="<?php echo e(url('/')); ?>/css/bootstrap.min.css" rel="stylesheet">

        <!-- Custom styles for this template -->
        <link href="<?php echo e(url('/')); ?>/css/style.css" rel="stylesheet">
        <link href="<?php echo e(url('/')); ?>/css/responsive.css" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('/')); ?>/css/bootstrap-social.css" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('/')); ?>/css/font-awesome.css" rel="stylesheet" type="text/css">

        <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
        <!--[if lt IE 9]><script src="js/ie8-responsive-file-warning.js"></script><![endif]-->
    </head>

    <body>

        <!-- Static navbar -->
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('/')); ?>/images/logo-main.png" class="img-responsive" alt=""></a> </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <?php if(Auth::guest()): ?>
                        <li><a href="<?php echo e(url('/')); ?>">Login</a></li>
                        <li><a href="<?php echo e(url('/register')); ?>">Register</a></li>
                        <?php else: ?>
                        <li><a href="<?php echo e(url('/logout')); ?>">Logout</a></li>
                        <li><a href="<?php echo e(url('/contact')); ?>">Contact List</a></li>
                        <li class="welcome"><a href="#.">Welcome <strong><?php echo e(Auth::user()->name); ?></strong></a></li>
                        <?php endif; ?>
                    </ul>
                </div>
                <!--/.nav-collapse --> 
            </div>
        </nav>
        <?php echo $__env->yieldContent('content'); ?>
        <footer class="footer">
            <div class="container text-center">
                <p class="text-muted">Copyright © 2016 Contact Book. All Rights Reserved.<br>
                    <a href="#">Privacy Policy</a><br>
                    <img src="<?php echo e(url('/')); ?>/images/logo-footer.png" alt="" class="img-responsive"> </p>
            </div>
        </footer>


        <!-- Bootstrap core JavaScript
            ================================================== --> 
        <!-- Placed at the end of the document so the pages load faster --> 
        <script src="<?php echo e(url('/')); ?>/js/jquery.min.js"></script> 
        <script src="<?php echo e(url('/')); ?>/js/bootstrap.min.js"></script> 
        <script src="<?php echo e(url('/')); ?>/js/bootbox.js"></script> 
        <script type="text/javascript">
var fieldshown = 0;
var removedarray = new Array();
$(function () {
    $(document).on('submit', '#frm-contact', function (e) {
        e.preventDefault();
        var data = $(this).serialize();
        $.ajax({
            url: '<?php echo url("contact/store"); ?>',
            type: 'POST',
            data: data,
            cache: false,
            success: function (data, textStatus, jqXHR) {
                if (data == 'invalid_form') {
                    $('.alert').css('display', 'block');
                    $('.alert').html("Fill Valid Data Before Submit");
                } else {
                    $('.alert').css('display', 'block');
                    $('.alert').html("Contact Added Sucessfully");
                    setTimeout(function () {
                        $('#frm-contact')[0].reset();
                        $('#myModal').modal('hide');
                        $('#contacts-list').html(data)
                    }, 2000);
                }
            }
        });
    });

    $(document).on('submit', '#frm-contact-edit', function (e) {
        e.preventDefault();
        var data = $(this).serialize();
        $.ajax({
            url: '<?php echo url("contact/update")."/".$contact->id; ?>',
            type: 'PUT',
            data: data,
            cache: false,
            success: function (data, textStatus, jqXHR) {
                if (data == 'invalid_form') {
                    $('.alert').css('display', 'block');
                    $('.alert').html("Fill Valid Data Before Submit");
                } else {
                    $('.alert').css('display', 'block');
                    $('.alert').html("Contact updated Sucessfully");
                    setTimeout(function () {
                        $('#frm-contact-edit')[0].reset();
                        $('#myModal').modal('hide');
                        $('#contacts-list').html(data)
                    }, 2000);
                }
            }
        });
    });
    $('body').on('click', '#btn-addfield', function () {
        if (fieldshown == 0) {
            $('#extrafields .form-group').each(function (i) {
                if ($(this).attr('style') == 'display: block') {
                    fieldshown++;
                }
            });
        }
        if (fieldshown < 5) {
            fieldshown++;
            $('.efiled' + fieldshown).removeAttr('style');
        } else if (removedarray.length > 0) {
            var index = 5 - (5 - (removedarray.length - 1));
            $('.' + removedarray[index]).val('');
            $('.' + removedarray[index]).show();
            removedarray.splice(index, 1);
        }
    });
});
var removefi = function (finame) {
    removedarray.push(finame);
    $('.' + finame).hide();
    $('.' + finame + ' input[type="text"]').val('');
};

var loadEdit = function (id) {
    var data = "id=" + id;
    $('#myModal').load('<?php echo url("contact/edit"); ?>/' + id);
    fieldshown = 0;
    removedarray = new Array();
};
var loadAdd = function () {
    $('#myModal').load('<?php echo url("contact/loadform"); ?>');
    fieldshown = 0;
    removedarray = new Array();
};

var deleteCon = function (id) {
    bootbox.confirm("Are you sure want to delete?", function (result) {
        if (result == true) {
            var data = {"_token": "<?php echo e(csrf_token()); ?>"};
            $.ajax({
                url: "<?php echo e(url('contact/destroy')); ?>" + "/" + id,
                type: 'DELETE',
                data: data,
                cache: false,
                success: function (data, textStatus, jqXHR) {
                    $('#contacts-list').html(data)
                }
            });
        }
    });
};
        </script>
    </body>
</html>
