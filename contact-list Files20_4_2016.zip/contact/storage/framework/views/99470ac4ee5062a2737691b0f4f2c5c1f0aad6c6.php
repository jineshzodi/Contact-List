<?php foreach($contacts as $contact): ?>
<div class="dash-board">

    <div class="col-md-2 hd-1"><?php echo e($contact->name); ?></div>
    <div class="col-md-2 hd-2"><?php echo e($contact->surname); ?></div>
    <div class="col-md-4 hd-3"><?php echo e($contact->email); ?></div>
    <div class="col-md-2 hd-4"><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span><?php echo e($contact->phone); ?></div>
    <div class="col-md-2">
        <button type="button" class="btn btn-23" onclick="deleteCon(<?php echo e($contact->id); ?>)"> <span class="glyphicon glyphicon-minus"></span> </button>
        <button type="button" class="btn btn-23" data-toggle="collapse" data-target="#collapse<?php echo e($contact->id); ?>" aria-expanded="false" aria-controls="collapseExample"> <span class="glyphicon glyphicon-plus"></span> </button>
        <button type="button" class="btn btn-23" onclick="loadEdit(<?php echo e($contact->id); ?>)" data-toggle="modal" data-target="#myModal"> <span class="glyphicon glyphicon-pencil"></span> </button>
    </div>
    <div class="clearfix"></div>

    <div class="collapse" id="collapse<?php echo e($contact->id); ?>">
        <div class="well"> <?php echo e($contact->efield1); ?>  <?php echo e(' - '.$contact->efield2); ?>  <?php echo e(' - '.$contact->efield3); ?>  <?php echo e(' - '.$contact->efield4); ?>  <?php echo e($contact->efield5); ?>

        </div>
    </div>
</div>
<?php endforeach; ?>