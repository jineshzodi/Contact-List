@foreach($contacts as $contact)
<div class="dash-board">

    <div class="col-md-2 hd-1">{{ $contact->name }}</div>
    <div class="col-md-2 hd-2">{{ $contact->surname }}</div>
    <div class="col-md-4 hd-3">{{ $contact->email }}</div>
    <div class="col-md-2 hd-4"><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>{{ $contact->phone }}</div>
    <div class="col-md-2">
        <button type="button" class="btn btn-23" onclick="deleteCon({{ $contact->id }})"> <span class="glyphicon glyphicon-minus"></span> </button>
        <button type="button" class="btn btn-23" data-toggle="collapse" data-target="#collapse{{ $contact->id }}" aria-expanded="false" aria-controls="collapseExample"> <span class="glyphicon glyphicon-plus"></span> </button>
        <button type="button" class="btn btn-23" onclick="loadEdit({{ $contact->id }})" data-toggle="modal" data-target="#myModal"> <span class="glyphicon glyphicon-pencil"></span> </button>
    </div>
    <div class="clearfix"></div>

    <div class="collapse" id="collapse{{ $contact->id }}">
        <div class="well"> {{ $contact->efield1 }}  {{ ' - '.$contact->efield2 }}  {{ ' - '.$contact->efield3 }}  {{ ' - '.$contact->efield4 }}  {{ $contact->efield5 }}
        </div>
    </div>
</div>
@endforeach