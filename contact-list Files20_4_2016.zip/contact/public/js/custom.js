var fieldshown = 0;
var removedarray = new Array();
$(function () {
    $(document).on('submit', '#frm-contact', function (e) {
        e.preventDefault();
        var data = $(this).serialize();
        $.ajax({
            url: '{!! url("contact/store") !!}',
            type: 'POST',
            data: data,
            cache: false,
            success: function (data, textStatus, jqXHR) {
                if (data == 'invalid_form') {
                    $('.alert').css('display', 'block');
                    $('.alert').html("Fill Valid Data Before Submit");
                } else {
                    $('.alert').css('display', 'block');
                    $('.alert').html("Contact Added Sucessfully");
                    setTimeout(function () {
                        $('#frm-contact')[0].reset();
                        $('#myModal').modal('hide');
                        $('#contacts-list').html(data)
                    }, 2000);
                }
            }
        });
    });

    $(document).on('submit', '#frm-contact-edit', function (e) {
        e.preventDefault();
        var data = $(this).serialize();
        $.ajax({
            url: '{!! url("contact/update")."/".$contact->id !!}',
            type: 'PUT',
            data: data,
            cache: false,
            success: function (data, textStatus, jqXHR) {
                if (data == 'invalid_form') {
                    $('.alert').css('display', 'block');
                    $('.alert').html("Fill Valid Data Before Submit");
                } else {
                    $('.alert').css('display', 'block');
                    $('.alert').html("Contact updated Sucessfully");
                    setTimeout(function () {
                        $('#frm-contact-edit')[0].reset();
                        $('#myModal').modal('hide');
                        $('#contacts-list').html(data)
                    }, 2000);
                }
            }
        });
    });
    $('body').on('click', '#btn-addfield', function () {
        if (fieldshown == 0) {
            $('#extrafields .form-group').each(function (i) {
                if ($(this).attr('style') == 'display: block') {
                    fieldshown++;
                }
            });
        }
        if (fieldshown < 5) {
            fieldshown++;
            $('.efiled' + fieldshown).removeAttr('style');
        } else if (removedarray.length > 0) {
            var index = 5 - (5 - (removedarray.length - 1));
            $('.' + removedarray[index]).val('');
            $('.' + removedarray[index]).show();
            removedarray.splice(index, 1);
        }
    });
});
var removefi = function (finame) {
    removedarray.push(finame);
    $('.' + finame).hide();
    $('.' + finame + ' input[type="text"]').val('');
};

var loadEdit = function (id) {
    var data = "id=" + id;
    $('#myModal').load('{!! url("contact/edit") !!}/' + id);
    fieldshown = 0;
    removedarray = new Array();
};
var loadAdd = function () {
    $('#myModal').load('{!! url("contact/loadform") !!}');
    fieldshown = 0;
    removedarray = new Array();
};

var deleteCon = function (id) {
    bootbox.confirm("Are you sure want to delete?", function (result) {
        if (result == true) {
            var data = {"_token": "{{ csrf_token() }}"};
            $.ajax({
                url: "{{ url('contact/destroy') }}" + "/" + id,
                type: 'DELETE',
                data: data,
                cache: false,
                success: function (data, textStatus, jqXHR) {
                    $('#contacts-list').html(data)
                }
            });
        }
    });
};