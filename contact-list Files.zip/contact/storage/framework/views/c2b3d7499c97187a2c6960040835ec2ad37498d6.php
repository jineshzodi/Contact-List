<?php $__env->startSection('content'); ?>
<section class="head-cell">
    <div class="container">
        <h1><span>Free Contact Book Demo</span></h1>
    </div>
</section>
<!-- /head-cell -->

<div class="container login-cell">

    <div class="col-md-12">
        <h2>Welcome to the Login</h2>
    </div>

    <div class="col-md-6 col-sm-offset-3">
        <div class="form-shadow">
            <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                <?php echo csrf_field(); ?>

                <input type="hidden" name="redirect_to" value="">
                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <input type="text" name="email" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="E-mail" required>
                </div>
                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <input type="password" name="password" id="user_pass" class="form-control" placeholder="Password" required>
                </div>
                <div class="form-group">
                    <div class="checkbox">
                        <input type="checkbox" name="rememberme" id="rememberme" value="forever" checked="">
                        <label for="rememberme">
                            <small>Remember Me</small>
                        </label>
                    </div>
                </div>
                <div class="form-group">
                    <input type="submit" value="Sign In" class="btn btn-default">
                </div>
                <div class="form-group"><img src="images/or.jpg" class="img-responsive" alt=""> </div>
                <div class="form-group">
                    <a class="btn btn-block btn-social btn-facebook" href="<?php echo e(url('/login/facebook')); ?>">
                        <span class="fa fa-facebook"></span> Sign in with Facebook
                    </a>
                    <a class="btn btn-block btn-social btn-github" href="<?php echo e(url('/login/github')); ?>">
                        <span class="fa fa-github"></span> Sign in with GitHub
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- /container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>