<?php $__env->startSection('content'); ?>
<section class="head-cell">
    <div class="container">
        <h1><span>Free Contact Book Demo</span></h1>
    </div>
</section>

<div class="container login-cell">
    <div class="col-md-6 col-sm-offset-3">
        <div class="form-shadow">

            <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                <?php echo csrf_field(); ?>


                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                    <input type="text" placeholder="Name" class="form-control" name="name" value="<?php echo e(old('name')); ?>">

                    <?php if($errors->has('name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>

                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <input type="email" placeholder="Email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">

                    <?php if($errors->has('email')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>

                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <input placeholder="Password" type="password" class="form-control" name="password">

                    <?php if($errors->has('password')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>

                <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                    <input type="password" placeholder="Confirm Password" class="form-control" name="password_confirmation">

                    <?php if($errors->has('password_confirmation')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <input type="submit" class="btn btn-default" value="Register" />
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>