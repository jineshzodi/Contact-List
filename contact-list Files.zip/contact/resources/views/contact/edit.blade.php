<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="myModalLabel">Add <span>/</span> Edit <span>/</span> Delete <span>/</span> <strong>Contact</strong></h4>
        </div>
        {!! Form::open(array('action' => ['ContactController@update', $contact->id],'method' => 'PUT','class'=>'form-horizontal')) !!}
        {!! csrf_field() !!}
        <div class="modal-body">
            <article>
                <div class="alert alert-info" style="display: none"></div>
                <div class="form-group">
                    <div class="col-sm-12">
                        {!! Form::hidden('campaign_id',$contact->campaign_id) !!}
                        {!! Form::text('name',$contact->name, ['class'=>'form-control','placeholder'=>'Name']); !!}
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-12">
                        {!! Form::text('surname',$contact->surname, ['class'=>'form-control','placeholder'=>'Surname']); !!}
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-12">
                        {!! Form::email('email',$contact->email, ['class'=>'form-control','placeholder'=>'Email']); !!}
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-12">
                        {!! Form::number('phone',$contact->phone, ['class'=>'form-control','placeholder'=>'Phone']); !!}
                    </div>
                </div>
                <div id="extrafields">
                    <div class="form-group efiled1" style="{{ (empty($contact->efield1)?"display: none":"display: block") }}">
                        <div class="col-sm-11 col-xs-11">
                            {!! Form::text('field1',$contact->efield1, ['class'=>'form-control','placeholder'=>'']); !!}
                        </div>
                        <div class="col-sm-1 col-xs-1">
                            <button type="button" onclick="removefi('efiled1')" class="btn btn-23 pull-right"> <span class="glyphicon glyphicon-minus"></span> </button>
                        </div>
                    </div>
                    <div class="form-group efiled2" style="{{ (empty($contact->efield2)?"display: none":"display: block") }}">
                        <div class="col-sm-11 col-xs-11">
                            {!! Form::text('field2',$contact->efield2, ['class'=>'form-control','placeholder'=>'']); !!}
                        </div>
                        <div class="col-sm-1 col-xs-1">
                            <button type="button" onclick="removefi('efiled2')" class="btn btn-23 pull-right"> <span class="glyphicon glyphicon-minus"></span> </button>
                        </div>
                    </div>
                    <div class="form-group efiled3" style="{{ (empty($contact->efield3)?"display: none":"display: block") }}">
                        <div class="col-sm-11 col-xs-11">
                            {!! Form::text('field3',$contact->efield3, ['class'=>'form-control','placeholder'=>'']); !!}
                        </div>
                        <div class="col-sm-1 col-xs-1">
                            <button type="button" onclick="removefi('efiled3')" class="btn btn-23 pull-right"> <span class="glyphicon glyphicon-minus"></span> </button>
                        </div>
                    </div>
                    <div class="form-group efiled4" style="{{ (empty($contact->efield4)?"display: none":"display: block") }}">
                        <div class="col-sm-11 col-xs-11">
                            {!! Form::text('field4',$contact->efield4, ['class'=>'form-control','placeholder'=>'']); !!}
                        </div>
                        <div class="col-sm-1 col-xs-1">
                            <button type="button" onclick="removefi('efiled4')" class="btn btn-23 pull-right"> <span class="glyphicon glyphicon-minus"></span> </button>
                        </div>
                    </div>
                    <div class="form-group efiled5" style="{{ (empty($contact->efield5)?"display: none":"display: block") }}">
                        <div class="col-sm-11 col-xs-11">
                            {!! Form::text('field5',$contact->efield5, ['class'=>'form-control','placeholder'=>'']); !!}
                        </div>
                        <div class="col-sm-1 col-xs-1">
                            <button type="button" onclick="removefi('efiled5')" class="btn btn-23 pull-right"> <span class="glyphicon glyphicon-minus"></span> </button>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-12">
                        <button type="button" id="btn-addfield" class="btn btn-23 pull-right" style="color: #000 !important"> <span class="glyphicon glyphicon-plus"></span> Add Field</button>
                    </div>
                </div>
            </article>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn  btn-primary btn-default-3" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-default">Update Contact</button>
        </div>
        {!! Form::close() !!}
    </div>
</div>