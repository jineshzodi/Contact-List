<?php

/*
  |--------------------------------------------------------------------------
  | Application Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register all of the routes for an application.
  | It's a breeze. Simply tell Laravel the URIs it should respond to
  | and give it the controller to call when that URI is requested.
  |
 */
//Routes to contact Controller
Route::post('contact/store', [
    'uses' => 'ContactController@store',
    'as' => 'contact/store'
]);

Route::get('contact/edit/{id}', [
    'uses' => 'ContactController@edit',
    'as' => 'contact/edit'
]);

Route::delete('contact/destroy/{id}', [
    'uses' => 'ContactController@destroy',
    'as' => 'contact/destroy'
]);

Route::get('contact/search/{keyword}', [
    'uses' => 'ContactController@search',
    'as' => 'contact/search'
]);

Route::get('contact/loadform', 'ContactController@loadform');
Route::resource('contact', 'ContactController');
//Route::auth();
//Social Login
Route::get('/login/{provider?}', [
    'uses' => 'Auth\AuthController@getSocialAuth',
    'as' => 'auth.getSocialAuth'
]);

Route::get('/login/callback/{provider?}', [
    'uses' => 'Auth\AuthController@getSocialAuthCallback',
    'as' => 'auth.getSocialAuthCallback'
]);

// Authentication routes...
Route::get('/', 'Auth\AuthController@getLogin');
Route::post('/login', 'Auth\AuthController@postLogin');
Route::get('/logout', 'Auth\AuthController@logout');

// Registration routes...
Route::get('/register', 'Auth\AuthController@getRegister');
Route::post('/register', 'Auth\AuthController@postRegister');
